<!-- Thank you for using Iceberg! -->
<!-- Make sure your environment before submitting a issue. -->
Environment:
- OS
- Vim (`:version`)
- Terminal

If you have a trouble with coloration and are using Vim/Neovim with terminal:
- [ ] Does your Vim support full colors? (`:set termguicolors`)
- [ ] Does your terminal support full colors? (e.g. Terminal.app doesn't support it)
